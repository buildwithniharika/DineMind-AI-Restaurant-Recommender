---
name: Botanical Culinary Minimal
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#5c403c'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#916f6b'
  outline-variant: '#e6bdb8'
  surface-tint: '#bf0715'
  primary: '#b70011'
  on-primary: '#ffffff'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#ffb4ab'
  secondary: '#575e70'
  on-secondary: '#ffffff'
  secondary-container: '#d9dff5'
  on-secondary-container: '#5c6274'
  tertiary: '#b21618'
  on-tertiary: '#ffffff'
  tertiary-container: '#d6332d'
  on-tertiary-container: '#fff7f6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#dce2f7'
  secondary-fixed-dim: '#c0c6db'
  on-secondary-fixed: '#141b2b'
  on-secondary-fixed-variant: '#404758'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ab'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#93000b'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
  crimson-primary: '#DC2626'
  crimson-deep: '#B91C1C'
  crimson-tint: '#FEF2F2'
  crimson-border: '#FECACA'
  surface-pure: '#FFFFFF'
  text-primary: '#111827'
  text-secondary: '#374151'
  text-muted: '#6B7280'
  border-rule: '#E5E7EB'
  border-subtle: '#F3F4F6'
typography:
  display:
    fontFamily: Epilogue
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-mobile:
    fontFamily: Epilogue
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Epilogue
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  space-4xl: 6rem
  gutter-mobile: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin-mobile: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 4rem
---

## Brand & Style
This design system pairs architectural minimalism with refined gastronomic precision. Tailored for elevated culinary platforms, fine dining tools, and artisanal gastronomy, the visual narrative centers on deliberate reduction: pure white backdrops, razor-sharp hairline borders, deep charcoal typography, and focal strikes of culinary crimson red.

The aesthetic dismisses decorative excess and photographic clutter in favor of bespoke, vector-drawn botanical and culinary line art. Interface elements communicate discipline, poise, and curated taste. Interactions feel intentional, tactile, and clear—evoking the measured restraint of a fine culinary monograph or an architectural tasting menu.

## Colors
The palette operates on pure chromatic tension between an uncompromising white surface, rich charcoal structural elements, and a decisive culinary crimson red (#DC2626 / #B91C1C) that supersedes all prior terracotta and rust tones.

- **Base Surfaces**: The entire canvas rests on pure white (`#FFFFFF`). Depth is structured through fine boundary rules rather than off-white or tinted grey surface steps.
- **Primary & Accent**: `#DC2626` is reserved for focal calls to action, critical navigation landmarks, active selections, and refined line accents. Its deeper counterpart, `#B91C1C`, anchors active/hover states, high-contrast text accents, and pressed interactions. `#FEF2F2` is utilized sparingly for high-clarity active indicators or chip fills.
- **Typography & Structural Elements**:
  - Primary Headlines & Key Text: Deep charcoal black (`#111827`).
  - Secondary Body: Grounded dark grey (`#374151`).
  - Meta, Captions & Labels: Balanced neutral grey (`#6B7280`).
- **Dividers & Structural Rules**:
  - Primary borders and frames: Hairline `#E5E7EB`.
  - Inset partitions and internal grid dividers: Subtle `#F3F4F6`.

## Typography
Typographic scale unites the sculptural, deliberate presence of Epilogue with the sharp, rational legibility of Hanken Grotesk.

- **Display & Headlines**: Epilogue anchors editorial authority. Tighter tracking creates strong visual mass on wide margins and white negative space.
- **Body & Captions**: Hanken Grotesk provides neutral, clear readability. Generous line heights ensure recipes, botanical descriptions, and culinary logs remain effortless to scan.
- **Metadata & Indicators**: Labels and technical specifications employ small, uppercase tracking in Hanken Grotesk to emulate classic botanical indexing and culinary provenance documentation.

## Layout & Spacing
The layout model employs a fixed, architectural grid structured with generous vertical cadence:

- **Grid Framework**: Desktop layouts utilize a 12-column grid with `gutter-desktop` (2rem) and `margin-desktop` (4rem). Tablets scale to 8 columns with `1.5rem` gutters. Mobile environments collapse into a disciplined 4-column structure with `1.25rem` outer gutters.
- **Vertical Spacing & Hierarchy**: Generous whitespace allocations (`space-3xl` and `space-4xl`) act as structural breaks between distinct sections, treating each block of content with the gallery-like presence of an art catalog plate.
- **Micro Spacing**: Internal component spacing relies strictly on multiples of `0.25rem` (4px), maintaining balanced alignment between line-drawn icons, typography baseline bounds, and containment borders.

## Elevation & Depth
Depth is created exclusively through **low-contrast outlines and micro-hairlines**. Drop shadows, colored card floods, and soft blur elevations are omitted to preserve architectural crispness.

- **Surface Levels**: All containers, modules, and modals exist on `#FFFFFF`. Tonal differentiation is achieved via 1px geometric borders (`#E5E7EB` for containers and `#F3F4F6` for internal dividers).
- **Overlays & Drawers**: Modals, slide-out menus, and dropdowns sit above the page canvas, bounded by a 1px `#E5E7EB` border. If layered separation over complex line art is required, a disciplined frosted scrim is applied using `backdrop-filter: blur(8px)` with an `rgba(255, 255, 255, 0.94)` background fill.

## Shapes
Geometry is sharp, tailored, and architectural. The system adopts a **Soft (1)** shape language:

- **Base Components**: Standard controls, buttons, text fields, and chips utilize `0.25rem` (4px) corner radiuses.
- **Containers**: Cards, sheets, dialogs, and popovers utilize `0.5rem` (8px) corner radiuses.
- **Pill & Circular Elements**: Strict full rounding is restricted exclusively to status pips, counters, and botanical vector badges.

## Components

### Buttons
- **Primary**: Solid culinary crimson (`#DC2626`) fill, pure white (`#FFFFFF`) text, `0.25rem` corner radius, 1px solid transparent border. On hover and focus: deepens to `#B91C1C`. Active state maintains sharp focus ring via `outline: 2px solid #DC2626` with a `2px` white offset.
- **Secondary / Outline**: Clean `#FFFFFF` fill, deep charcoal (`#111827`) text, bounded by a 1px solid `#E5E7EB` border. On hover: border transitions cleanly to `#111827`.
- **Tertiary / Ghost**: Transparent fill, `#374151` text. On hover: text transitions to culinary crimson (`#DC2626`) with a subtle `#FEF2F2` background tint.

### Inputs & Selects
- Pure `#FFFFFF` background, framed by a 1px solid `#E5E7EB` border. Typography uses `#111827` for entered values and `#9CA3AF` for placeholder hints.
- Active focus state sharpens the border directly to 1px solid `#DC2626` without ambient glow rings or diffuse shadows.
- Validation states replace the border with `#B91C1C` accompanied by an inline micro-caption in `label-sm`.

### Cards & Culinary Spec Sheets
- Pure `#FFFFFF` surface enclosed in a 1px solid `#E5E7EB` rule, using `0.5rem` border radius.
- Padding adheres strictly to `space-lg` (1.5rem) or `space-xl` (2rem).
- Sub-sections, preparation metrics, and ingredient divisions use hairline rules in `#F3F4F6`.

### Chips & Culinary Tags
- Fixed height of 28px with `0.25rem` radius. Default state features a `#FFFFFF` fill, 1px `#E5E7EB` border, and `#4B5563` text set in `label-md`.
- Active/Selected state: border shifts to 1px solid `#DC2626`, text turns `#DC2626`, with an optional subtle background wash of `#FEF2F2`.

### Checkboxes & Radio Controls
- Base (Unchecked): Clean `#FFFFFF` fill surrounded by a 1px `#E5E7EB` perimeter.
- Checked: Solid `#DC2626` fill with a crisp `#FFFFFF` hairline checkmark or centered radio dot. On hover: border tightens to `#B91C1C`.

### Iconography & Botanical Vector Artwork
- **Style**: Vector line illustrations only. Raster photography and solid planar fills are strictly avoided.
- **Line Weight**: Consistent 1.25px to 1.5px stroke weight.
- **Coloration**: Strokes are rendered in `#111827` for standard navigational glyphs, or culinary crimson (`#DC2626`) for highlighted botanical motifs (e.g., rosemary sprigs, sea salt crystals, brassica leaves, chef's shears).